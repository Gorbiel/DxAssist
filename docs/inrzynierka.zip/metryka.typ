#let your_title = "Projekt i implementacja zintegrowanego systemu analizy danych medycznych z wykorzystaniem sztucznej inteligencji"
#let short_title = "Praca dyplomowa"
#let desc = "Metryka pracy inżynierskiej, grupa 6"
#let authors = ("Damian Chłus", "Jakub Gucwa", "Gabriel Kania", "Filip Malejki")
#let version = "0.1.0"
#let date = datetime.today()

#set page(
  paper: "us-letter", 
  flipped: true,
  number-align: center, 
  numbering: "1 z 1", 
  margin: 1.5cm,
  header-ascent: 30%,
  footer-descent: 25%,
  footer: [#line(stroke: 0.5pt, start:(-1cm, 0pt), end: (100% + 1cm, 0pt))
  #grid(
    columns: (4fr, 1fr, 0.8fr),
    [#desc], [wersja: #version], [#align(right)[#context counter(page).display("1 z 1", both: true)]]
  )
  ],
  header: [#grid(
  columns: (2fr, 1fr),
    [*Autorzy*: #authors.join(", ")],[#align(right)[#date.display("[day].[month].[year]")]])
    #line(stroke: 0.5pt, start:(-1cm, 0pt), end: (100% + 1cm, 0pt))
  ]
)
#set heading(numbering: "1.")
#set text(fallback: true, hyphenate: auto, kerning: true, lang: "pl", font: "Spectral", weight: "light")
#set footnote.entry(
  separator: line(length: 100%)
)
#set par(justify: true)
#set list(indent: 1.5em, marker: (sym.bullet.op, sym.bullet.stroked))
#set rect(width: auto)
#show link: underline
#show link: set text(fill: blue)

#set document(
  title: your_title, 
  description: desc,
  author: authors,
  date: date
)

#title()

#heading(text(desc, weight: "semibold"), outlined: false, numbering: none, level: 2)

\

+ *Nazwa projektu*: #your_title
+ *Skład zespołu*: #authors.join(", ")
+ *Opiekun*: dr inż. Anna Wójcicka
+ *Repozytorium*: https://github.com/Gorbiel/DxAssist
+ *Dokumentacja*: https://typst.app/project/RaKK3Qvz3DmZWNzFLAa2EY
+ *Tablica z zadaniami*: https://github.com/users/Gorbiel/projects/8