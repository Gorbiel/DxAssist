#let your_title = "Projekt i implementacja zintegrowanego systemu analizy danych medycznych z wykorzystaniem sztucznej inteligencji"
#let short_title = "Praca dyplomowa"
#let desc = "Harmonogram pracy inżynierskiej, grupa 6"
#let authors = ("Damian Chłus", "Jakub Gucwa", "Gabriel Kania", "Filip Malejki")
#let version = "0.1.0"
#let date = datetime.today()

#set page(
  paper: "us-letter", 
  flipped: false,
  number-align: center, 
  numbering: "1 z 1", 
  margin: 1.5cm,
  header-ascent: 30%,
  footer-descent: 25%,
  footer: [#line(stroke: 0.5pt, start:(-1cm, 0pt), end: (100% + 1cm, 0pt))
  #grid(
    columns: (4fr, 1fr, 0.8fr),
    [#desc], [wersja: #version], [#align(right)[#context counter(page).display("1 z 1", both: true)]]
  )
  ],
  header: [#grid(
  columns: (2fr, 1fr),
    [*Autorzy*: #authors.join(", ")],[#align(right)[#date.display("[day].[month].[year]")]])
    #line(stroke: 0.5pt, start:(-1cm, 0pt), end: (100% + 1cm, 0pt))
  ]
)
#set heading(numbering: "1.")
#set text(fallback: true, hyphenate: auto, kerning: true, lang: "pl", font: "Spectral", weight: "light")
#set footnote.entry(
  separator: line(length: 100%)
)
#set par(justify: true)
#set list(indent: 1.5em, marker: (sym.bullet.op, sym.bullet.stroked))
#set rect(width: auto)
#show link: underline
#show link: set text(fill: blue)

#set document(
  title: your_title, 
  description: desc,
  author: authors,
  date: date
)

#set table(
  inset: 8pt,
  stroke: (x, y) => {
    if y == 0 {
      (bottom: 1.2pt + rgb("#2F3A4A"))
    } else {
      0.5pt + rgb("#D7DBE0")
    }
  },
)

#show table.cell.where(y: 0): set text(
  fill: white,
  weight: "bold",
)

#show table.cell.where(y: 0): set align(center)

#show table.cell.where(y: 0): set block(
  fill: rgb("#2F3A4A"),
)

#let team-color(team) = {
  if team == "Backend" {
    rgb("#DCEBFF")
  } else if team == "ML" {
    rgb("#E6F4EA")
  } else if team == "Infra" {
    rgb("#FFF4D6")
  } else if team == "Frontend" {
    rgb("#F1E6FF")
  } else {
    rgb("#F2F2F2")
  }
}

#let row(week, task, desc, team, result, issue) = (
  table.cell(fill: team-color(team))[#week],
  table.cell(fill: team-color(team))[#task],
  table.cell(fill: team-color(team))[#desc],
  table.cell(fill: team-color(team))[#team],
  table.cell(fill: team-color(team))[#result],
  table.cell(fill: team-color(team))[#issue],
)

#title()

#heading(text(desc, weight: "semibold"), outlined: false, numbering: none, level: 2)

#outline()

#pagebreak()

#set page(
  flipped: true
)

= Maj

#table(
  columns: (auto, 1.6fr, 3fr, auto, 1.6fr, auto),

  table.header(
    [Tydzień], [Zadanie], [Krótki opis], [Typ], [Rezultat], [Issue],
  ),

  ..row(
    [1-3],
    [Inicjalizacja projektu],
    [Utworzenie szkieletu projektu i podstawowej struktury.],
    "Infra",
    [W trakcie],
    [#link("https://github.com/users/Gorbiel/projects/8/views/1?pane=issue&itemId=189139969&issue=Gorbiel%7CDxAssist%7C3")[\#6]]
  ),

    ..row(
    [4],
    [Stworzenie makietowych modułów (Mocks)],
    [Przygotowanie modułów testowych.],
    "ML",
    [W trakcie],
    [#link("https://github.com/users/Gorbiel/projects/8/views/1?pane=issue&itemId=189141846&issue=Gorbiel%7CDxAssist%7C7")[\#7]]
  ),


)

#pagebreak()
= Czerwiec

#table(
  columns: (auto, 1.6fr, 3fr, auto, 1.6fr, auto),

  table.header(
    [Tydzień], [Zadanie], [Krótki opis], [Typ], [Rezultat], [Issue],
  ),

    ..row(
    [1-4],
    [Infrastruktura],
    [Przygotowanie środowiska, deployu i zasobów.],
    "Infra",
    [W trakcie],
    [#link("https://github.com/users/Gorbiel/projects/8/views/1?pane=issue&itemId=189138291&issue=Gorbiel%7CDxAssist%7C3")[\#3]]
  ),

    ..row(
    [2],
    [Stworzenie Schedulera],
    [Budowa mechanizmu uruchamiania, wywoływania i wybierania modułów.],
    "Backend",
    [W trakcie],
    [#link("https://github.com/users/Gorbiel/projects/8/views/1?pane=issue&itemId=189141882&issue=Gorbiel%7CDxAssist%7C8")[\#8]]
  ),
  
  ..row(
    [2-4],
    [Dokumentacja dołączania modułów],
    [Opis zasad wpinania modułów do schedulera.],
    "Docs",
    [W trakcie],
    [#link("https://github.com/users/Gorbiel/projects/8/views/1?pane=issue&itemId=189143054&issue=Gorbiel%7CDxAssist%7C9")[\#9]]
  ),

      ..row(
    [3],
    [Logowanie i rejestracja do systemu],
    [Stworzenie kont i systemu logowania się, oraz rejestrowania nowego użytkownika przez Admina.],
    "Backend",
    [W trakcie],
    [#link("https://github.com/users/Gorbiel/projects/8/views/1?pane=issue&itemId=189143394&issue=Gorbiel%7CDxAssist%7C10")[\#10]]
  ),
  

  ..row(
    [4],
    [Stworzenie UI do przekazywania danych i otrzymywania outputów],
    [Interfejs do wprowadzania danych medycznych i odbierania wyników.],
    "Frontend",
    [W trakcie],
    [#link("https://github.com/users/Gorbiel/projects/8/views/1?pane=issue&itemId=189144210&issue=Gorbiel%7CDxAssist%7C11")[\#11]]
  ),
)